console.log("Extension Script Loaded");

try {
    // Function to detect and remove the suspicious modal and blur mask
    function removeSuspiciousModal() {
        const suspiciousModal = [...document.querySelectorAll(".ant-modal-body")]
            .find(body => body.textContent.includes("Suspicious extension detected"));

        if (suspiciousModal) {
            console.log("Suspicious modal detected. Removing modal and blur mask...");

            // Find and remove the modal root element
            const modalRoot = suspiciousModal.closest(".ant-modal-root");
            if (modalRoot) {
                modalRoot.remove();
                console.log("Suspicious modal removed successfully.");
            }

            // Remove the blur mask
            const blurMask = document.querySelector(".ant-modal-mask");
            if (blurMask) {
                blurMask.remove();
                console.log("Blur mask removed successfully.");
            }
        }
    }

    // Use MutationObserver to detect modal dynamically when it appears
    const observer = new MutationObserver(() => {
        const suspiciousModal = [...document.querySelectorAll(".ant-modal-body")]
            .find(body => body.textContent.includes("Suspicious extension detected"));

        if (suspiciousModal) {
            observer.disconnect(); // Stop observing once detected
            removeSuspiciousModal(); // Remove the modal and blur
        }
    });

    // Start observing the DOM for changes
    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });

    console.log("MutationObserver initialized. Watching for suspicious extension modal...");
} catch (error) {
    console.error("An error occurred:", error);
}